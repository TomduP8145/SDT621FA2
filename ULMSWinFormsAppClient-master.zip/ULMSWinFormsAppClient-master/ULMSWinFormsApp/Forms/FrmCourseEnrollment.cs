﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmCourseEnrollment : Form
    {
        private List<Enrollment> enrollments = new List<Enrollment>();

        public FrmCourseEnrollment()
        {
            InitializeComponent();
            txtEnrollStudentName.KeyPress += txtEnrollStudentName_KeyPress;
        }

        private void txtEnrollStudentName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
                MessageBox.Show("Only letters are allowed in the Student Name field.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            string studentId = txtEnrollStudentId.Text.Trim();
            string studentName = txtEnrollStudentName.Text.Trim();
            string course = cmbCourse.Text.Trim();
            string semester = cmbSemester.Text.Trim();

            if (string.IsNullOrEmpty(studentId) ||
                string.IsNullOrEmpty(studentName) ||
                string.IsNullOrEmpty(course) ||
                string.IsNullOrEmpty(semester))
            {
                MessageBox.Show("All fields are required.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEnrollmentOutput.Clear();
                return;
            }

            if (!Regex.IsMatch(studentName, @"^[A-Za-z\s]+$"))
            {
                MessageBox.Show("Please enter a valid name (letters only).", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEnrollmentOutput.Clear();
                return;
            }

            bool alreadyEnrolled = enrollments.Exists(e =>
                e.StudentId.Equals(studentId, StringComparison.OrdinalIgnoreCase) &&
                e.CourseName.Equals(course, StringComparison.OrdinalIgnoreCase) &&
                e.Semester.Equals(semester, StringComparison.OrdinalIgnoreCase));

            if (alreadyEnrolled)
            {
                MessageBox.Show("This student is already enrolled in the selected course and semester.",
                    "Duplicate Enrollment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEnrollmentOutput.Clear();
                return;
            }

            Enrollment enrollment = new Enrollment
            {
                StudentId = studentId,
                StudentName = studentName,
                CourseName = course,
                Semester = semester
            };

            enrollments.Add(enrollment);

            txtEnrollmentOutput.Text =
                "Enrollment completed successfully!\n" +
                $"Student ID: {enrollment.StudentId}\n" +
                $"Student Name: {enrollment.StudentName}\n" +
                $"Course: {enrollment.CourseName}\n" +
                $"Semester: {enrollment.Semester}";
        }

        private void btnClearEnrollment_Click(object sender, EventArgs e)
        {
            txtEnrollStudentId.Clear();
            txtEnrollStudentName.Clear();
            cmbCourse.SelectedIndex = -1;
            cmbSemester.SelectedIndex = -1;
            txtEnrollmentOutput.Clear();
            txtEnrollStudentId.Focus();
        }

        private void btnBackEnrollment_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
