﻿using System;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmReportGeneration : Form
    {
        public FrmReportGeneration()
        {
            InitializeComponent();
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            txtReportOutput.Text =
                "Student Performance Report\n" +
                "---------------------------\n" +
                "All student data displayed correctly.";
        }

        private void btnClearReport_Click(object sender, EventArgs e)
        {
            txtReportOutput.Clear();
        }

        private void btnBackReport_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
