﻿using System;
using System.Windows.Forms;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmDashboard : Form
    {
        public FrmDashboard()
        {
            InitializeComponent();
        }

        private void btnOpenEnrollment_Click(object sender, EventArgs e)
        {
            FrmCourseEnrollment enrollmentForm = new FrmCourseEnrollment();
            enrollmentForm.ShowDialog();
        }

        private void btnOpenMarks_Click(object sender, EventArgs e)
        {
            FrmMarksCapture marksForm = new FrmMarksCapture();
            marksForm.ShowDialog();
        }

        private void btnOpenReports_Click(object sender, EventArgs e)
        {
            FrmReports reportsForm = new FrmReports();
            reportsForm.ShowDialog();
        }

        private void btnOpenRegistration_Click(object sender, EventArgs e)
        {
            FrmStudentRegistration regForm = new FrmStudentRegistration();
            regForm.ShowDialog();
        }

        private void btnExitDashboard_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
