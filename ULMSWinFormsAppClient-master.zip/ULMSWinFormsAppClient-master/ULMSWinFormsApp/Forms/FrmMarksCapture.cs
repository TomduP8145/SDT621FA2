﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmMarksCapture : Form
    {
        public FrmMarksCapture()
        {
            InitializeComponent();
            txtMarkStudentName.KeyPress += txtMarkStudentName_KeyPress;
        }

        private void txtMarkStudentName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true;
                MessageBox.Show("Only letters are allowed in the Student Name field.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCalculateResults_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMarkStudentId.Text) ||
                string.IsNullOrWhiteSpace(txtMarkStudentName.Text) ||
                string.IsNullOrWhiteSpace(txtSubject1.Text) ||
                string.IsNullOrWhiteSpace(txtSubject2.Text) ||
                string.IsNullOrWhiteSpace(txtSubject3.Text))
            {
                MessageBox.Show("All fields are required.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!Regex.IsMatch(txtMarkStudentName.Text.Trim(), @"^[A-Za-z\s]+$"))
            {
                MessageBox.Show("Please enter a valid name (letters only).", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!double.TryParse(txtSubject1.Text, out double subject1) ||
                !double.TryParse(txtSubject2.Text, out double subject2) ||
                !double.TryParse(txtSubject3.Text, out double subject3))
            {
                MessageBox.Show("Please enter numeric values for all subjects.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            double average = (subject1 + subject2 + subject3) / 3;
            string result = average >= 50 ? "PASS" : "FAIL";

            txtMarksOutput.Text =
                $"Student ID: {txtMarkStudentId.Text}\n" +
                $"Student Name: {txtMarkStudentName.Text}\n" +
                $"Average: {average}\n" +
                $"Result: {result}";
        }

        private void btnClearMarks_Click(object sender, EventArgs e)
        {
            txtMarkStudentId.Clear();
            txtMarkStudentName.Clear();
            txtSubject1.Clear();
            txtSubject2.Clear();
            txtSubject3.Clear();
            txtMarksOutput.Clear();
            txtMarkStudentId.Focus();
        }

        private void btnBackMarks_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
